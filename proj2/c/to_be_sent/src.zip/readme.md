# How to compile and run the programs?

## Install [GLFW](http://www.glfw.org)
## Run ../release.sh in your target directory
## Run ./main
