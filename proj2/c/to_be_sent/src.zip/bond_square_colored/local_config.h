#ifndef LOCAL_CONFIG_H
#define LOCAL_CONFIG_H
#include <global_config.h>

/* nr of samples */
#define PERC_MAX_LVL 1500

#define WORLD_WIDTH SCR_WIDTH
#define WORLD_HEIGHT SCR_HEIGHT

#endif
